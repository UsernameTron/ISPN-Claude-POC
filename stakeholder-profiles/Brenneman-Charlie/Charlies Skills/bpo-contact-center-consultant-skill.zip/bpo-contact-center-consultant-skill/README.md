# BPO Contact Center Consultant Skill

## Overview

Executive-level contact center operations consulting for ISP/BPO environments with sophisticated counter-factual analysis, what-if scenario modeling, and strategic optimization.

## Key Capabilities

**Counter-Factual Analysis**
- "What if we had X more agents?" → Quantified impact with Erlang C
- "What if training happened 6 months earlier?" → ROI modeling
- "What if we optimized routing?" → Process efficiency gains

**Strategic Consulting**
- Root cause analysis (5 Whys, Fishbone, Pareto)
- Capacity planning with Erlang C
- Financial impact modeling (cost per contact, ROI, NPV)
- Industry benchmarking
- Transformation roadmaps

**Analytical Frameworks**
- Regression analysis for driver identification
- Time-series decomposition
- Cohort analysis
- Monte Carlo simulation
- Theory of Constraints

## When Claude Uses This Skill

- "What if" questions about staffing, processes, or investments
- Scenario modeling and analysis
- Strategic recommendations
- Root cause investigation
- Capacity planning
- Financial justification for initiatives
- Industry benchmarking requests
- Executive consulting needs

## Industry Benchmarks Included

**Call Center Metrics:**
- FCR: 70-75% (avg), 80-85% (world class)
- AHT: 10-15 min (technical support)
- AWT: <90 sec (standard), <60 sec (good)
- Abandonment: <5% (goal), >10% (problem)

**Staffing:**
- Utilization: 50-60% (L1-L3), 70-80% (NOC)
- Shrinkage: 25-35% typical
- Attrition: <15% excellent, 20-30% average

**Financial:**
- Cost per contact: $8-15 (outsourced), $15-25 (in-house)
- Contacts per FTE: 25-40 daily (technical support)

## Installation

### For Claude.ai
1. Zip the `bpo-contact-center-consultant-skill` folder
2. Settings > Capabilities > Skills > Upload Skill
3. Select ZIP file and enable

### For Claude Code
Place folder in workspace - auto-detected

### For API
Upload via skill endpoint with proper dependencies

## Dependencies

- Python ≥3.8
- pandas ≥2.0.0
- numpy ≥1.24.0
- scipy ≥1.10.0 (for Erlang C calculations)

## Example Usage

```
"If we had 3 more agents during peak hours in October, 
what would our average wait time have been?"

→ Claude provides:
  - Baseline actual performance
  - Erlang C modeling with additional agents
  - Quantified improvement in AWT, service level, abandonment
  - Financial impact (cost vs benefit)
  - Feasibility assessment
  - Implementation recommendation
```

```
"What if we had invested in training 6 months ago? 
What would FCR be now?"

→ Claude provides:
  - Industry research on training impact
  - Counter-factual performance modeling
  - Financial ROI calculation
  - Sensitivity analysis
  - Opportunity cost assessment
  - Implementation roadmap
```

## Skill Components

- **SKILL.md**: Main skill instructions and frameworks
- **REFERENCE.md**: Advanced methodologies and formulas
- **README.md**: This file
- **/scripts**: Python utilities for calculations
  - `erlang_c.py`: Capacity planning calculations
  - `roi_calculator.py`: Financial impact modeling
  - `root_cause_analyzer.py`: Structured problem investigation

## What Makes This Different

**vs Basic Analytics**: Goes beyond reporting to strategic consulting
**vs Generic Skills**: ISP/BPO-specific context and benchmarks
**vs Reactive Analysis**: Proactive counter-factual modeling
**vs Point Solutions**: Comprehensive operational transformation

## Consulting Frameworks Included

1. **Operations Assessment** (2-4 weeks)
2. **Transformation Program** (3-12 months)
3. **Root Cause Analysis** (5 Whys, Fishbone, Pareto)
4. **Gap Analysis** (Current → Desired State)
5. **SWOT Analysis** (Strategic positioning)
6. **Balanced Scorecard** (Multi-dimensional performance)

## Best Practices

**For Counter-Factual Analysis:**
- Start with clear baseline (what actually happened)
- Use conservative assumptions
- Provide sensitivity analysis
- Quantify both costs and benefits
- Assess feasibility honestly

**For Strategic Recommendations:**
- Prioritize by ROI and feasibility
- Include implementation timeline
- Specify success metrics
- Address change management
- Provide risk mitigation

**For Financial Modeling:**
- Use client's actual cost structure
- Include both direct and indirect benefits
- Model multiple scenarios
- Calculate NPV for multi-year initiatives
- Show payback period

## Troubleshooting

**Issue**: Counter-factual seems unrealistic  
**Solution**: Check assumptions, use sensitivity analysis, reference industry benchmarks

**Issue**: ROI too high to be credible  
**Solution**: Verify calculations, use conservative estimates, show break-even

**Issue**: Recommendations not actionable  
**Solution**: Add specific next steps, timelines, resource requirements, owners

## Support

**Version**: 1.0.0  
**Created**: 2025-11-12  
**Maintained By**: Contact Center Excellence Team

For issues or enhancements, contact your operations leadership.

---

## Quick Start Examples

### Example 1: Staffing Analysis
```
Upload: WCS or DPR file
Ask: "If we had 5 more techs during peak hours, how would that 
impact our wait times and what would it cost?"
Get: Full Erlang C analysis with ROI
```

### Example 2: Training Investment
```
Upload: Historical performance data
Ask: "What would our FCR be if we had done advanced training 
in Q2? What's the ROI?"
Get: Counter-factual modeling with financial impact
```

### Example 3: Process Optimization
```
Upload: Current metrics
Ask: "What if we implemented skills-based routing? What 
improvements would we see?"
Get: Industry benchmarks, impact model, implementation plan
```

### Example 4: Root Cause Investigation
```
Upload: Performance data
Ask: "Why is our escalation rate stuck at 35%? What are 
the root causes?"
Get: 5 Whys analysis, prioritized causes, corrective actions
```

### Example 5: Strategic Planning
```
Upload: Annual performance
Ask: "What are our top 3 operational improvement opportunities 
for next year?"
Get: SWOT analysis, prioritized roadmap, ROI for each
```

## Advanced Features

### Erlang C Capacity Planning
Calculates optimal staffing based on:
- Call volume forecasts
- Target service levels
- Handle time objectives
- Shrinkage factors
- Occupancy targets

### Monte Carlo Simulation
Models uncertainty in forecasts:
- Range of outcomes
- Confidence intervals
- Risk assessment
- Downside scenarios

### Financial Impact Modeling
Quantifies business impact:
- Cost per contact
- Labor optimization
- Revenue protection
- ROI and NPV
- Payback period

### Root Cause Frameworks
Structured problem-solving:
- 5 Whys technique
- Fishbone diagrams
- Pareto analysis (80/20)
- Constraint theory
- Regression analysis

## Integration with ISPN Tech Center Analytics

This skill **complements** the existing ISPN Tech Center Analytics skill:

**ISPN Analytics**: What happened? (Descriptive)
**BPO Consultant**: What if? Why? What should we do? (Prescriptive)

**Use Together:**
1. Upload data
2. ISPN Analytics skill shows current performance
3. BPO Consultant skill models alternatives and recommends actions

**Example Combined Usage:**
```
"Show me October performance" (ISPN Analytics)
→ Sees FCR at 68.9%, Escalations at 34.9%

"If we had done advanced training in August, where would 
FCR be now?" (BPO Consultant)
→ Counter-factual shows FCR would be 73.5%
→ Provides ROI calculation and implementation plan
```

---

**Ready to use!** Upload your performance data and ask strategic "what if" questions.
