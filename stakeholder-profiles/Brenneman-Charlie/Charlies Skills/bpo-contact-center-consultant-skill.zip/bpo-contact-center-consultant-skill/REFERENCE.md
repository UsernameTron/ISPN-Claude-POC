# BPO Contact Center Consultant - Reference Guide

## Advanced Formulas & Calculations

### Erlang C Formula

**Purpose**: Calculate probability of queueing and service level

```python
import math
from scipy.special import factorial

def erlang_c(agents, calls_per_hour, avg_handle_time_hours):
    """
    Erlang C probability of queueing
    
    Returns: Probability (0-1) that call will queue
    """
    load = calls_per_hour * avg_handle_time_hours
    rho = load / agents
    
    if rho >= 1:
        return 1.0  # System overloaded
    
    # Erlang C calculation
    erlang_b_sum = sum([(load ** k) / factorial(k) for k in range(agents)])
    erlang_b = (load ** agents) / factorial(agents)
    
    prob_wait = erlang_b / (erlang_b + (1 - rho) * erlang_b_sum)
    
    return prob_wait

def service_level(agents, calls_per_hour, aht_minutes, target_seconds):
    """
    Calculate % calls answered within target time
    
    Returns: Service level as decimal (0-1)
    """
    aht_hours = aht_minutes / 60
    pw = erlang_c(agents, calls_per_hour, aht_hours)
    
    load = calls_per_hour * aht_hours
    
    # Service level formula
    sl = 1 - (pw * math.exp(-(agents - load) * (target_seconds / (aht_minutes * 60))))
    
    return sl

def agents_required(calls_per_hour, aht_minutes, target_seconds, target_sl):
    """
    Calculate agents needed for target service level
    
    Binary search to find minimum agents
    """
    min_agents = int(calls_per_hour * aht_minutes / 60) + 1
    max_agents = min_agents * 3
    
    while min_agents < max_agents:
        mid = (min_agents + max_agents) // 2
        sl = service_level(mid, calls_per_hour, aht_minutes, target_seconds)
        
        if sl >= target_sl:
            max_agents = mid
        else:
            min_agents = mid + 1
    
    return min_agents
```

### Capacity Planning Formulas

**Required FTE**
```
Required_FTE = (Call_Volume × AHT) / (Available_Hours × Target_Occupancy × (1 - Shrinkage))

Where:
- Call_Volume: Expected calls per period
- AHT: Average Handle Time (hours)
- Available_Hours: Working hours per period
- Target_Occupancy: 0.75-0.85 for most contact centers
- Shrinkage: 0.25-0.35 (PTO, breaks, training, meetings)
```

**Occupancy Rate**
```
Occupancy = (Talk_Time + ACW + Hold_Time) / (Total_Available_Time)

Optimal Range: 75-85%
- <70%: Underutilized (high idle time)
- >90%: Burnout risk (no breathing room)
```

**Utilization Rate**
```
Utilization = (Talk_Time + ACW) / (Total_Scheduled_Time)

Target Ranges:
- L1-L3 Support: 50-60%
- NOC: 70-80%
- Outbound: 40-50%
```

**Shrinkage Calculation**
```
Shrinkage = (PTO + Breaks + Training + Meetings + Other_Non_Productive) / Total_Scheduled_Hours

Typical Breakdown:
- PTO/Sick: 8-12%
- Breaks: 8-10%
- Training: 3-5%
- Meetings: 3-5%
- Other: 2-5%
Total: 25-35%
```

### Financial Formulas

**Cost Per Contact (CPC)**
```
CPC = Total_Labor_Cost / Total_Contacts

Components:
- Direct Labor: Agent wages + benefits
- Indirect Labor: Supervisors, QA, training staff
- Overhead: Technology, facilities, admin

Benchmark: $8-15 (outsourced), $15-25 (in-house)
```

**Labor Cost Percentage**
```
Labor_% = Total_Labor_Cost / Total_Revenue

Healthy Range: 35-50% for BPO operations
```

**ROI Calculation**
```
ROI = (Total_Benefit - Total_Cost) / Total_Cost × 100%

Payback_Period = Total_Cost / (Annual_Benefit / 12)

NPV = Σ(Benefit_t - Cost_t) / (1 + r)^t

Where:
- t: Time period (years)
- r: Discount rate (typically 8-12%)
```

**Attrition Cost**
```
Cost_Per_Departure = Recruiting + Training + Ramp_Cost + Lost_Productivity

Typical: $8,000-12,000 per L1 tech
- Recruiting: $1,000-2,000
- Training: $3,000-4,000 (4-6 weeks)
- Ramp: $2,000-3,000 (productivity gap)
- Lost Productivity: $2,000-3,000
```

### Statistical Formulas

**Standard Deviation & Confidence Intervals**
```python
import numpy as np

def calculate_confidence_interval(data, confidence=0.95):
    """
    Calculate mean and confidence interval
    """
    mean = np.mean(data)
    std_error = np.std(data, ddof=1) / np.sqrt(len(data))
    
    # Z-score for 95% confidence: 1.96
    z_score = 1.96 if confidence == 0.95 else 2.576  # 99%
    
    margin = z_score * std_error
    
    return {
        'mean': mean,
        'lower': mean - margin,
        'upper': mean + margin,
        'std_error': std_error
    }
```

**Correlation Analysis**
```python
def analyze_correlation(x, y):
    """
    Calculate correlation coefficient and significance
    """
    from scipy.stats import pearsonr
    
    corr, p_value = pearsonr(x, y)
    
    interpretation = {
        'correlation': corr,
        'p_value': p_value,
        'significant': p_value < 0.05,
        'strength': 'strong' if abs(corr) > 0.7 else 
                   'moderate' if abs(corr) > 0.4 else 'weak',
        'direction': 'positive' if corr > 0 else 'negative'
    }
    
    return interpretation
```

**Regression Analysis**
```python
from scipy.stats import linregress

def predict_impact(independent_var, dependent_var):
    """
    Linear regression to predict impact
    """
    slope, intercept, r_value, p_value, std_err = linregress(independent_var, dependent_var)
    
    return {
        'slope': slope,  # Impact per unit change
        'intercept': intercept,
        'r_squared': r_value ** 2,  # Explanatory power
        'p_value': p_value,
        'std_error': std_err
    }

# Example: Impact of training hours on FCR
# result = predict_impact(training_hours, fcr_values)
# Interpretation: Each additional training hour → +slope% FCR
```

### Industry Benchmarks

**Service Level Standards**
```
Industry Standard: 80/X (80% of calls in X seconds)

Conservative (Technical Support):
- 80/90: 80% in 90 seconds (ISPN standard)
- 80/120: 80% in 120 seconds (acceptable)

Aggressive (Retail/Simple):
- 80/60: 80% in 60 seconds (good)
- 80/20: 80% in 20 seconds (world class)
```

**First Call Resolution Benchmarks**
```
Industry Averages by Type:
- Simple inquiries: 80-85%
- Technical support: 70-75%
- Complex troubleshooting: 60-70%
- Account/billing: 75-80%

ISPN Context: Technical support (70-75% range)
Target: >70% (at industry average)
World Class: >80%
```

**Average Handle Time by Industry**
```
Retail/Simple: 3-6 minutes
Customer Service: 6-9 minutes
Technical Support (L1): 8-12 minutes
Technical Support (L2): 12-18 minutes
Complex Troubleshooting: 15-25 minutes

ISPN Target: <10.7 minutes (good for technical support)
```

**Abandonment Rate Standards**
```
World Class: <3%
Good: 3-5%
Acceptable: 5-8%
Problem: 8-10%
Critical: >10%

Factors:
- Wait time correlation: +30 sec → +2-3% abandonment
- IVR quality: Poor IVR → +5-10% abandonment
- Callback option: Can reduce 20-40%
```

**Technician Performance Distribution**
```
Typical Performance Curve:

Top 20% (High Performers):
- FCR: +15-20% above average
- AHT: 10-15% better than average
- Quality: 95%+ scores
- Attrition: 5-10% annually

Middle 60% (Solid Performers):
- FCR: ±10% of average
- AHT: Within 10% of average
- Quality: 85-95% scores
- Attrition: 20-25% annually

Bottom 20% (Development Needed):
- FCR: -15-25% below average
- AHT: 15-30% worse than average
- Quality: <85% scores
- Attrition: 40-50% annually
```

## Counter-Factual Modeling Techniques

### Technique 1: Baseline-Alternative-Impact (BAI)

**Template**:
```
1. BASELINE: What actually happened
   - Metric values
   - Context and constraints
   - Time period

2. ALTERNATIVE: What could have happened
   - Changed variable(s)
   - Mechanism of impact
   - Expected relationship

3. IMPACT: Quantified difference
   - Operational metrics
   - Financial impact
   - Customer impact
   - Strategic implications
```

### Technique 2: Sensitivity Analysis

**Purpose**: Test robustness of findings

```python
def sensitivity_analysis(base_case, variable_range, impact_function):
    """
    Model how outcome changes with variable
    """
    results = []
    
    for value in variable_range:
        outcome = impact_function(value)
        results.append({
            'variable_value': value,
            'outcome': outcome,
            'change_vs_base': outcome - base_case
        })
    
    return results

# Example: How does FCR improvement vary with training hours?
# training_range = [20, 30, 40, 50, 60]
# outcomes = sensitivity_analysis(baseline_fcr, training_range, fcr_model)
```

### Technique 3: Monte Carlo for Uncertainty

**Purpose**: Model range of outcomes under uncertainty

```python
import numpy as np

def monte_carlo_simulation(n_simulations=10000):
    """
    Model outcome distribution with uncertain inputs
    """
    results = []
    
    for _ in range(n_simulations):
        # Random variables (example: training impact)
        fcr_improvement = np.random.normal(0.04, 0.01)  # 4% ± 1%
        attrition_reduction = np.random.uniform(0.02, 0.05)  # 2-5%
        
        # Calculate outcome
        revenue_impact = fcr_improvement * churn_correlation * revenue_per_sub
        cost_savings = attrition_reduction * techs * replacement_cost
        
        total_benefit = revenue_impact + cost_savings
        results.append(total_benefit)
    
    return {
        'mean': np.mean(results),
        'median': np.median(results),
        'p10': np.percentile(results, 10),  # Pessimistic
        'p90': np.percentile(results, 90),  # Optimistic
        'std_dev': np.std(results)
    }

# Interpretation:
# - Median: Most likely outcome
# - P10: Conservative case (90% chance of exceeding)
# - P90: Optimistic case (10% chance of exceeding)
```

## Root Cause Analysis Frameworks

### 5 Whys Template

```
PROBLEM: [State the problem clearly]

Why 1: [First level cause]
Why 2: [Deeper cause - why did Why 1 happen?]
Why 3: [Even deeper - why did Why 2 happen?]
Why 4: [Root cause emerging]
Why 5: [Ultimate root cause - organizational/systemic]

ROOT CAUSE: [Final answer from Why 5]

VALIDATION:
- If we address this root cause, will it prevent the problem?
- Is this within our control to fix?
- Have we gone deep enough?

CORRECTIVE ACTION: [What to fix]
PREVENTIVE ACTION: [How to prevent recurrence]
```

### Fishbone (Ishikawa) Diagram

**Categories for Contact Center Issues**:

```
People:
- Training adequacy
- Experience levels
- Morale and engagement
- Turnover/attrition
- Skill gaps

Process:
- Call routing logic
- Escalation procedures
- Quality assurance
- Knowledge management
- Workflow efficiency

Technology:
- System reliability
- Tool adequacy
- Integration issues
- Data availability
- Automation gaps

Management:
- Goal setting
- Performance tracking
- Coaching frequency
- Resource allocation
- Decision making

Environment:
- Workspace conditions
- Schedule flexibility
- Work-life balance
- Company culture
- External factors

Policies:
- SLA definitions
- Performance incentives
- Staffing models
- Training requirements
- Quality standards
```

### Pareto Analysis (80/20 Rule)

```python
def pareto_analysis(issues_with_counts):
    """
    Identify vital few vs trivial many
    """
    import pandas as pd
    
    df = pd.DataFrame(issues_with_counts)
    df = df.sort_values('count', ascending=False)
    df['cumulative'] = df['count'].cumsum()
    df['cumulative_pct'] = df['cumulative'] / df['count'].sum()
    
    # Find 80% threshold
    vital_few = df[df['cumulative_pct'] <= 0.80]
    
    return {
        'vital_few': vital_few,
        'num_vital': len(vital_few),
        'pct_vital': len(vital_few) / len(df),
        'impact_vital': vital_few['count'].sum() / df['count'].sum()
    }

# Example: Escalation reasons
# issues = [
#     {'reason': 'WiFi troubleshooting', 'count': 1200},
#     {'reason': 'Partner system access', 'count': 800},
#     {'reason': 'Complex billing', 'count': 600},
#     ...
# ]
# result = pareto_analysis(issues)
# Focus on top 20% of reasons causing 80% of escalations
```

## Forecasting Methodologies

### Simple Moving Average (SMA)

```python
def moving_average(data, window=4):
    """
    Smooth noisy data with moving average
    """
    return data.rolling(window=window).mean()

# Example: 4-week moving average of FCR
# fcr_smoothed = moving_average(fcr_weekly, window=4)
```

### Exponential Smoothing

```python
def exponential_smoothing(data, alpha=0.3):
    """
    Weight recent data more heavily
    
    alpha: Smoothing factor (0-1)
    - Higher alpha: More weight to recent data
    - Lower alpha: More smoothing
    """
    result = [data[0]]
    
    for i in range(1, len(data)):
        smoothed = alpha * data[i] + (1 - alpha) * result[-1]
        result.append(smoothed)
    
    return result
```

### Linear Trend Extrapolation

```python
def forecast_linear_trend(historical_data, periods_ahead):
    """
    Forecast using linear regression
    """
    from scipy.stats import linregress
    
    x = range(len(historical_data))
    slope, intercept, r_value, _, _ = linregress(x, historical_data)
    
    # Forecast
    forecast = []
    for i in range(periods_ahead):
        future_x = len(historical_data) + i
        forecast.append(slope * future_x + intercept)
    
    return {
        'forecast': forecast,
        'trend_slope': slope,
        'r_squared': r_value ** 2
    }
```

### Seasonal Decomposition

```python
def seasonal_decomposition(data, period=12):
    """
    Separate trend, seasonal, and residual components
    """
    from statsmodels.tsa.seasonal import seasonal_decompose
    
    result = seasonal_decompose(data, model='additive', period=period)
    
    return {
        'trend': result.trend,
        'seasonal': result.seasonal,
        'residual': result.resid,
        'original': data
    }

# Example: Monthly call volume
# - Trend: Long-term growth/decline
# - Seasonal: Month-of-year patterns
# - Residual: Random noise
```

## Change Impact Assessment

### Cost-Benefit Analysis Template

```
INITIATIVE: [Name]

ONE-TIME COSTS:
- Technology: $X
- Implementation: $X
- Training: $X
- Change management: $X
Total: $X

ONGOING COSTS (Annual):
- Maintenance: $X
- Additional labor: $X
- Licenses: $X
Total: $X

ONE-TIME BENEFITS:
- Process efficiency: $X
- Backlog reduction: $X
Total: $X

ONGOING BENEFITS (Annual):
- Labor savings: $X
- Revenue protection: $X
- Quality improvements: $X
Total: $X

FINANCIAL METRICS:
- Year 1 ROI: X%
- Payback Period: X months
- 3-Year NPV: $X
- Break-even: $X

INTANGIBLE BENEFITS:
- Customer satisfaction
- Employee morale
- Competitive advantage
- Operational flexibility

RISK ASSESSMENT:
- Implementation risk: LOW/MED/HIGH
- Adoption risk: LOW/MED/HIGH
- Financial risk: LOW/MED/HIGH

RECOMMENDATION: PROCEED/DEFER/MODIFY/REJECT
```

### Risk-Adjusted ROI

```python
def risk_adjusted_roi(base_roi, risk_level):
    """
    Adjust ROI for implementation risk
    
    risk_level: 'low', 'medium', 'high'
    """
    risk_factors = {
        'low': 0.95,     # 95% probability of success
        'medium': 0.75,  # 75% probability
        'high': 0.50     # 50% probability
    }
    
    risk_adj_roi = base_roi * risk_factors[risk_level]
    
    return risk_adj_roi

# Example: 
# base_roi = 800%
# risk = 'medium'
# adjusted = risk_adjusted_roi(800, 'medium')  # 600%
```

## Performance Optimization Frameworks

### Constraint Theory (Theory of Constraints)

**Five Focusing Steps**:

```
1. IDENTIFY the constraint
   - What's preventing us from achieving the goal?
   - Use data to find bottleneck
   - Example: Knowledge base outdated → high escalations

2. EXPLOIT the constraint
   - Get maximum output from constraint
   - Don't let constraint sit idle
   - Example: Update knowledge base with top escalation topics

3. SUBORDINATE everything else
   - Align all other processes to constraint
   - Don't optimize non-constraints
   - Example: Route complex calls to best KB-trained agents

4. ELEVATE the constraint
   - Add capacity or capability
   - Make major improvements
   - Example: Hire dedicated knowledge management team

5. REPEAT
   - When constraint is resolved, find next one
   - Continuous improvement cycle
   - Example: Next constraint might be agent training process
```

### Pareto Priority Matrix

**Priority Scoring**:
```
Priority_Score = (Impact × Probability × Urgency) / (Effort × Cost × Risk)

Where (scale 1-10):
- Impact: Business value if successful
- Probability: Likelihood of success
- Urgency: Time sensitivity
- Effort: Implementation difficulty
- Cost: Financial investment
- Risk: Potential downside

High Priority: Score >2.0
Medium Priority: Score 1.0-2.0
Low Priority: Score <1.0
```

## Implementation Roadmaps

### 90-Day Quick Wins Template

```
WEEK 1-2: Assessment
- Gather baseline data
- Identify quick wins
- Secure stakeholder buy-in
- Develop implementation plan

WEEK 3-4: Pilot
- Test with small group
- Measure impact
- Refine approach
- Build proof of concept

WEEK 5-8: Rollout
- Communicate change
- Train staff
- Implement solution
- Monitor closely

WEEK 9-12: Optimization
- Analyze results
- Make adjustments
- Standardize process
- Document lessons learned

SUCCESS METRICS:
- Week 2: Plan approved
- Week 4: Pilot results positive
- Week 8: Full rollout complete
- Week 12: Target metrics achieved
```

### Transformation Timeline Template

```
PHASE 1 (Months 1-3): FOUNDATION
- Current state assessment
- Gap analysis
- Strategic alignment
- Quick wins implementation

PHASE 2 (Months 4-6): CAPABILITY BUILDING
- Training programs
- Process redesign
- Technology enablement
- Team restructuring

PHASE 3 (Months 7-9): SCALING
- Rollout across organization
- Change management
- Performance tracking
- Course corrections

PHASE 4 (Months 10-12): OPTIMIZATION
- Continuous improvement
- Sustainability planning
- Knowledge transfer
- Celebrate success

GOVERNANCE:
- Weekly steering committee
- Monthly executive reviews
- Quarterly board updates
- Real-time dashboards
```

---

**Reference Version**: 1.0.0  
**Last Updated**: 2025-11-12  
**Maintained By**: Contact Center Excellence Team
