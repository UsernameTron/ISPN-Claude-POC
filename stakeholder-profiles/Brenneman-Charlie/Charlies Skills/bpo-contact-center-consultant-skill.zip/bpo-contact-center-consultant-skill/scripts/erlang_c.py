#!/usr/bin/env python3
"""
Erlang C Calculator for Contact Center Capacity Planning
Calculates agents required, service level, and wait times
"""

import math
from typing import Dict


def factorial(n: int) -> int:
    """Calculate factorial"""
    if n <= 1:
        return 1
    return math.factorial(n)


def erlang_c(agents: int, calls_per_hour: float, avg_handle_time_hours: float) -> float:
    """
    Calculate Erlang C probability of queueing
    
    Args:
        agents: Number of available agents
        calls_per_hour: Incoming call rate
        avg_handle_time_hours: Average handle time in hours
        
    Returns:
        Probability (0-1) that a call will have to queue
    """
    load = calls_per_hour * avg_handle_time_hours
    rho = load / agents
    
    if rho >= 1:
        return 1.0  # System overloaded
    
    # Erlang C formula
    erlang_b_sum = sum([(load ** k) / factorial(k) for k in range(agents)])
    erlang_b = (load ** agents) / factorial(agents)
    
    prob_wait = erlang_b / (erlang_b + (1 - rho) * erlang_b_sum)
    
    return prob_wait


def service_level(agents: int, calls_per_hour: float, 
                  aht_minutes: float, target_seconds: int) -> float:
    """
    Calculate service level (% calls answered within target time)
    
    Args:
        agents: Number of available agents
        calls_per_hour: Incoming call rate
        aht_minutes: Average handle time in minutes
        target_seconds: Target answer time in seconds
        
    Returns:
        Service level as decimal (0-1)
    """
    aht_hours = aht_minutes / 60
    pw = erlang_c(agents, calls_per_hour, aht_hours)
    
    load = calls_per_hour * aht_hours
    aht_seconds = aht_minutes * 60
    
    # Service level formula
    sl = 1 - (pw * math.exp(-(agents - load) * (target_seconds / aht_seconds)))
    
    return sl


def average_wait_time(agents: int, calls_per_hour: float, 
                      aht_minutes: float) -> float:
    """
    Calculate average wait time in seconds
    
    Args:
        agents: Number of available agents
        calls_per_hour: Incoming call rate
        aht_minutes: Average handle time in minutes
        
    Returns:
        Average wait time in seconds
    """
    aht_hours = aht_minutes / 60
    pw = erlang_c(agents, calls_per_hour, aht_hours)
    
    load = calls_per_hour * aht_hours
    aht_seconds = aht_minutes * 60
    
    # Average speed of answer
    awt = (pw * aht_seconds) / (agents - load)
    
    return awt


def agents_required(calls_per_hour: float, aht_minutes: float, 
                    target_seconds: int, target_sl: float) -> int:
    """
    Calculate agents needed to achieve target service level
    
    Args:
        calls_per_hour: Expected call volume per hour
        aht_minutes: Average handle time in minutes
        target_seconds: Target answer time (e.g., 90)
        target_sl: Target service level as decimal (e.g., 0.80 for 80%)
        
    Returns:
        Minimum number of agents required
    """
    # Start with theoretical minimum (Erlang B)
    load = calls_per_hour * (aht_minutes / 60)
    min_agents = int(load) + 1
    max_agents = int(load * 2) + 10
    
    # Binary search for minimum agents
    while min_agents < max_agents:
        mid = (min_agents + max_agents) // 2
        sl = service_level(mid, calls_per_hour, aht_minutes, target_seconds)
        
        if sl >= target_sl:
            max_agents = mid
        else:
            min_agents = mid + 1
    
    return min_agents


def occupancy_rate(agents: int, calls_per_hour: float, 
                   aht_minutes: float) -> float:
    """
    Calculate occupancy rate (productive time / available time)
    
    Returns:
        Occupancy as decimal (0-1)
    """
    aht_hours = aht_minutes / 60
    load = calls_per_hour * aht_hours
    
    occupancy = load / agents
    
    return occupancy


def capacity_analysis(calls_per_hour: float, aht_minutes: float,
                     target_seconds: int = 90, target_sl: float = 0.80) -> Dict:
    """
    Comprehensive capacity analysis
    
    Args:
        calls_per_hour: Expected call volume
        aht_minutes: Average handle time
        target_seconds: Target answer time (default 90)
        target_sl: Target service level (default 0.80)
        
    Returns:
        Dictionary with capacity metrics
    """
    required = agents_required(calls_per_hour, aht_minutes, target_seconds, target_sl)
    
    # Calculate metrics at required staffing
    sl = service_level(required, calls_per_hour, aht_minutes, target_seconds)
    awt = average_wait_time(required, calls_per_hour, aht_minutes)
    occ = occupancy_rate(required, calls_per_hour, aht_minutes)
    
    # Calculate metrics at various staffing levels for comparison
    scenarios = {}
    for delta in [-2, -1, 0, 1, 2]:
        agents = required + delta
        if agents > 0:
            scenarios[f'{delta:+d}'] = {
                'agents': agents,
                'service_level': service_level(agents, calls_per_hour, aht_minutes, target_seconds),
                'avg_wait_seconds': average_wait_time(agents, calls_per_hour, aht_minutes),
                'occupancy': occupancy_rate(agents, calls_per_hour, aht_minutes)
            }
    
    return {
        'inputs': {
            'calls_per_hour': calls_per_hour,
            'aht_minutes': aht_minutes,
            'target_answer_seconds': target_seconds,
            'target_service_level': target_sl
        },
        'recommended_agents': required,
        'service_level_achieved': sl,
        'avg_wait_time_seconds': awt,
        'occupancy_rate': occ,
        'scenarios': scenarios
    }


def what_if_staffing(current_agents: int, proposed_agents: int,
                     calls_per_hour: float, aht_minutes: float,
                     target_seconds: int = 90) -> Dict:
    """
    Compare current vs proposed staffing
    
    Returns:
        Comparison of metrics
    """
    current = {
        'agents': current_agents,
        'service_level': service_level(current_agents, calls_per_hour, aht_minutes, target_seconds),
        'avg_wait_seconds': average_wait_time(current_agents, calls_per_hour, aht_minutes),
        'occupancy': occupancy_rate(current_agents, calls_per_hour, aht_minutes)
    }
    
    proposed = {
        'agents': proposed_agents,
        'service_level': service_level(proposed_agents, calls_per_hour, aht_minutes, target_seconds),
        'avg_wait_seconds': average_wait_time(proposed_agents, calls_per_hour, aht_minutes),
        'occupancy': occupancy_rate(proposed_agents, calls_per_hour, aht_minutes)
    }
    
    improvement = {
        'agents_change': proposed_agents - current_agents,
        'service_level_improvement': proposed['service_level'] - current['service_level'],
        'wait_time_reduction': current['avg_wait_seconds'] - proposed['avg_wait_seconds'],
        'occupancy_change': proposed['occupancy'] - current['occupancy']
    }
    
    return {
        'current': current,
        'proposed': proposed,
        'improvement': improvement
    }


if __name__ == "__main__":
    # Example usage
    print("=" * 60)
    print("ERLANG C CAPACITY PLANNING")
    print("=" * 60)
    
    # Example: ISPN peak hour scenario
    calls_per_hour = 196
    aht_minutes = 10.7
    target_seconds = 90
    target_sl = 0.80
    
    print(f"\nInputs:")
    print(f"  Call Volume: {calls_per_hour} calls/hour")
    print(f"  Avg Handle Time: {aht_minutes} minutes")
    print(f"  Target: {target_sl:.0%} answered in {target_seconds} seconds")
    
    analysis = capacity_analysis(calls_per_hour, aht_minutes, target_seconds, target_sl)
    
    print(f"\nRecommended Staffing: {analysis['recommended_agents']} agents")
    print(f"  Service Level: {analysis['service_level_achieved']:.1%}")
    print(f"  Avg Wait Time: {analysis['avg_wait_time_seconds']:.0f} seconds")
    print(f"  Occupancy: {analysis['occupancy_rate']:.1%}")
    
    print("\nStaffing Scenarios:")
    for scenario, metrics in analysis['scenarios'].items():
        print(f"  {scenario} agents ({metrics['agents']}):")
        print(f"    Service Level: {metrics['service_level']:.1%}")
        print(f"    Avg Wait: {metrics['avg_wait_seconds']:.0f} sec")
        print(f"    Occupancy: {metrics['occupancy']:.1%}")
    
    # What-if comparison
    print("\n" + "=" * 60)
    print("WHAT-IF ANALYSIS: Current vs Proposed Staffing")
    print("=" * 60)
    
    current_agents = 14
    proposed_agents = 18
    
    comparison = what_if_staffing(current_agents, proposed_agents, 
                                  calls_per_hour, aht_minutes, target_seconds)
    
    print(f"\nCurrent ({current_agents} agents):")
    print(f"  Service Level: {comparison['current']['service_level']:.1%}")
    print(f"  Avg Wait: {comparison['current']['avg_wait_seconds']:.0f} seconds")
    print(f"  Occupancy: {comparison['current']['occupancy']:.1%}")
    
    print(f"\nProposed ({proposed_agents} agents):")
    print(f"  Service Level: {comparison['proposed']['service_level']:.1%}")
    print(f"  Avg Wait: {comparison['proposed']['avg_wait_seconds']:.0f} seconds")
    print(f"  Occupancy: {comparison['proposed']['occupancy']:.1%}")
    
    print(f"\nImprovement:")
    print(f"  Agents: {comparison['improvement']['agents_change']:+d}")
    print(f"  Service Level: {comparison['improvement']['service_level_improvement']:+.1%}")
    print(f"  Wait Time: {comparison['improvement']['wait_time_reduction']:+.0f} seconds")
    print(f"  Occupancy: {comparison['improvement']['occupancy_change']:+.1%}")
